package commandLine;

public class Sequence {

	public static void main(String args[ ]) {
		
		System.out.println("Number 1: "+args[0]);
		System.out.println("Number 2: "+args[1]);
		
		int count = 15, num1 = Integer.parseInt(args[0]), num2 = Integer.parseInt(args[1]);
        System.out.print("The sequence is:");

        for (int i = 1; i <= count; ++i)
        {
            System.out.print(num1+" ");

            
            int sumOfPrevTwo = num1 + num2;
            num1 = num2;
            num2 = sumOfPrevTwo;
        }
	}
}
