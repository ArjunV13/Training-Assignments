import java.util.Arrays;
import java.util.stream.Collectors;

public class Manipulate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "JAVA is Simple";
		
		System.out.println(str.toUpperCase());
		
		System.out.println(str.toLowerCase());
		
		System.out.println(str.charAt(0)+" "+str.charAt(5)+" "+str.charAt(8));
		
		System.out.println(str.replace("JAVA is Simple", "Simple is JAVA"));
		
		String result = Arrays.asList(str.split(" "))
                .stream()
                .map(s -> new StringBuilder(s).reverse())
                .collect(Collectors.joining(" "));
 
        System.out.println(result);
		
		System.out.println(str.replace(" ", "").length());
		
		
	}

}
