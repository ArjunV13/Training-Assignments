import java.util.ArrayList;

public class FindName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<String> al = new ArrayList<String>();
	      al.add("Arun");
	      al.add("Arjun");
	      al.add("Ram");
	      al.add("Sham");

	      System.out.println("ArrayList contains the string 'Arul': "+al.contains("Arul"));
	      
	      System.out.println("ArrayList contains the string 'Arjun': "+al.contains("Arjun"));
	                                             
	      System.out.println("ArrayList contains the string 'Ram': "+al.contains("Ram"));
	                                         
	      System.out.println("ArrayList contains the string 'Somu': "+al.contains("Somu"));
	                                           
	}

}
