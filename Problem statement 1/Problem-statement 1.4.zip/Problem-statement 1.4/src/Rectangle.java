
class Rect{
    
    double length, width;
     
    Rect()
    {
        length = 1;
        width = 1;
    }
     
    Rect(double length, double width)
    {
        this.length = length;
        this.width  = width;
    }
     
    double getArea()
    {
        return (length * width);
    }
     
    double getPerimeter()
    {
        return (2 * (length + width));
    }
}
public class Rectangle {
	 public static void main(String[] args) {
	        
         
	        Rect rect1 = new Rect();
	         
	        Rect rect2= new Rect(10.0,6.0);
	        
	        System.out.println("Area of first object="+rect1.getArea());
	        System.out.println("Perimeter of first object="+rect1.getPerimeter());
	        System.out.println("Area of second object="+rect2.getArea());
	        System.out.println("Perimeter of second object="+rect2.getPerimeter());
	   }
	    
}
