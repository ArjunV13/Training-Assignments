package calculateArea;

public class TestRectangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Rectangle r1 = new Rectangle();
		Rectangle r2 = new Rectangle(4, 4);
		Rectangle r3 = new Rectangle(10, 4);
		Rectangle r4 = new Rectangle(4,5);
		Rectangle r5 = new Rectangle(3, 9);
		
		r1.printInfo();
		r1.printArea();
		System.out.println(" ");
		
		r2.printInfo();
		r2.printArea();
		System.out.println(" ");
		
		r3.printInfo();
		r3.printArea();
		System.out.println(" ");
		
		r4.printInfo();
		r4.printArea();
		System.out.println(" ");
		
		r5.printInfo();
		r5.printArea();
		System.out.println(" ");
	
	}

}
