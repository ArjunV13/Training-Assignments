package calculateArea;

public class Rectangle {
	
	private int length;
	private int breadth;

	
	public Rectangle() {
	}


	// constructor to pass on length and breadth of a Rectangle
	
	public Rectangle(int length, int breadth) {
		this.length = length;
		this.breadth = breadth;
	}


	// create method printInfo( ) to print the two information about the rectangle.
	 
	public void printInfo() {
		System.out.println("Length: " + length);
		System.out.println("Breadth: " + breadth);
	}


	// create method printArea() to print the area of rectangle

	public void printArea() {
		int area = length * breadth;
		System.out.println("Area: " + area);
	}

}

