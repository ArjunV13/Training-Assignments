package com.mycompany.app;

import java.util.List;

import com.mycompany.dbutil.ProductConsole;
import com.mycompany.domain.Product;

public class ProductManagementApp {

	public static void main(String[] args) throws Exception {
		
		ProductConsole pc = new ProductConsole();
        pc.start();
	}
}
